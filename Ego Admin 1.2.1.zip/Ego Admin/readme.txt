=== Admin EgoSMS ===
Contributors: KEVINDJ Creatives
Tags: SMS, WooCommerce, Notifications, EgoSMS, Order Alerts
Requires at least: 5.0
Tested up to: 6.6
Stable tag: 1.0.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

**Admin EgoSMS** is an SMS integration for WooCommerce that automatically sends SMS texts to the Admin's phone number when a new order is placed or when an order fails. This plugin uses the EgoSMS service to handle SMS transactions. 

Once configured, you'll receive real-time SMS notifications directly to your phone, making it easier to manage your store's activities without constantly checking the dashboard.

== Features ==
* You need to have an account with EGOSMS.CO
* Automatically sends SMS to the Admin on new order placements.
* Notifies Admin when an order fails.
* Uses EgoSMS API for fast, reliable SMS delivery.
* Configurable admin phone number, EgoSMS username, password, and sender ID from the settings page.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to "Admin EgoSMS" in your WordPress admin sidebar to configure your EgoSMS credentials:
    - Admin Phone Number
    - EgoSMS Username
    - EgoSMS Password
    - EgoSMS Sender ID
4. Save your settings.
5. The plugin will now send SMS alerts when an order is placed or when an order fails in your WooCommerce store.

== Frequently Asked Questions ==

= How do I get my EgoSMS username, password, and sender ID? =

You can get these credentials by signing up for an account at [EgoSMS](https://egosms.co/) and accessing your credentials from their dashboard.

= Does this plugin work with all versions of WooCommerce? =

This plugin is tested to work with WooCommerce 5.0 and higher. It should work with any modern version of WooCommerce.

= Will the plugin send SMS to customers too? =

No, this plugin is designed to send SMS notifications to the Admin's phone number only. For customer notifications, you would need a separate integration.

= Can I change the content of the SMS messages? =

Currently, the plugin sends pre-configured messages, but future updates may include more customization options.

== Changelog ==

= 1.0 =
* Initial release of Admin EgoSMS plugin.

== Upgrade Notice ==

= 1.0 =
Initial release.

== License ==
This plugin is licensed under the GPLv2 or later.
