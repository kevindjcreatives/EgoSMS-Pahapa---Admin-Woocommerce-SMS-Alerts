<?php
/*
Plugin Name: Admin EgoSMS
Description: Sends SMS to the admin phone number when an order is placed or fails using the EgoSMS API.
Version: 1.2.1
Author: KEVINDJ Creatives
Author URI: https://kevindjcreatives.world/
Plugin URI: https://egosms.co/
License: GPLv2 or later
Text Domain: Admin EgoSMS
*/


// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Hook into WooCommerce order status changes
add_action('woocommerce_order_status_processing', 'admin_egosms_order_success');
add_action('woocommerce_order_status_cancelled', 'admin_egosms_order_cancelled');
add_action('woocommerce_order_status_failed', 'admin_egosms_order_failed');

// Function to handle successful order
function admin_egosms_order_success($order_id) {
    $order = wc_get_order($order_id);
    $message = "New AKRB-Order with ID:" . $order_id . " & Total: UGX" . $order->get_total() . " received";
    admin_send_egosms_notification($message);
}

// Function to handle order cancellation
function admin_egosms_order_cancelled($order_id) {
    $order = wc_get_order($order_id);
    $message = "An AKRB-Order has been cancelled. Order ID:" . $order_id;
    admin_send_egosms_notification($message);
}

// Function to handle failed order
function admin_egosms_order_failed($order_id) {
    $order = wc_get_order($order_id);
    $message = "An AKRB-Order failed. Order ID:" . $order_id;
    admin_send_egosms_notification($message);
}

// Function to send SMS notification to multiple numbers using EgoSMS API
function admin_send_egosms_notification($message) {
    // EgoSMS API credentials and settings
    $admin_phones = get_option('admin_egosms_phone'); // Multiple numbers separated by commas
    $egosms_username = get_option('admin_egosms_username');
    $egosms_password = get_option('admin_egosms_password');
    $egosms_sender = get_option('admin_egosms_sender');

    if (!$admin_phones || !$egosms_username || !$egosms_password || !$egosms_sender) {
        error_log('Admin EgoSMS Notifications: Missing API credentials or phone number(s).');
        return;
    }

    // Convert the comma-separated phone numbers into an array and trim whitespace
    $phone_numbers = array_map('trim', explode(',', $admin_phones));

    // Iterate over each phone number and send the SMS
    foreach ($phone_numbers as $phone) {
        // Prepare the API URL
        $url = "https://www.egosms.co/api/v1/plain/?";
        $parameters = "number=" . urlencode($phone) . "&message=" . urlencode($message) . "&username=" . urlencode($egosms_username) . "&password=" . urlencode($egosms_password) . "&sender=" . urlencode($egosms_sender);
        
        $response = wp_remote_get($url . $parameters);

        // Check for errors in the response
        if (is_wp_error($response)) {
            error_log('Admin EgoSMS Notifications: Failed to send SMS to ' . $phone . ' - ' . $response->get_error_message());
        } else {
            $response_body = wp_remote_retrieve_body($response);
            error_log('Admin EgoSMS Notifications: SMS sent to ' . $phone . ' - Response: ' . $response_body);
        }
    }
}

// Add settings page for admin to input EgoSMS API credentials
add_action('admin_menu', 'admin_egosms_settings_menu');

function admin_egosms_settings_menu() {
    add_menu_page(
        'Admin EgoSMS Settings',
        'Admin EgoSMS',
        'manage_options',
        'admin-egosms-settings',
        'admin_egosms_settings_page'
    );
}

// Display settings page
function admin_egosms_settings_page() {
    ?>
    <div class="wrap">
        <h1>Admin EgoSMS Notifications Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('admin_egosms_settings_group');
            do_settings_sections('admin_egosms_settings_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Admin Phone Numbers (comma-separated)</th>
                    <td><input type="text" name="admin_egosms_phone" value="<?php echo esc_attr(get_option('admin_egosms_phone')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">EgoSMS Username</th>
                    <td><input type="text" name="admin_egosms_username" value="<?php echo esc_attr(get_option('admin_egosms_username')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">EgoSMS Password</th>
                    <td><input type="password" name="admin_egosms_password" value="<?php echo esc_attr(get_option('admin_egosms_password')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">EgoSMS Sender ID</th>
                    <td><input type="text" name="admin_egosms_sender" value="<?php echo esc_attr(get_option('admin_egosms_sender')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register settings
add_action('admin_init', 'admin_egosms_register_settings');

function admin_egosms_register_settings() {
    register_setting('admin_egosms_settings_group', 'admin_egosms_phone');
    register_setting('admin_egosms_settings_group', 'admin_egosms_username');
    register_setting('admin_egosms_settings_group', 'admin_egosms_password');
    register_setting('admin_egosms_settings_group', 'admin_egosms_sender');
}
