<?php
/*
Plugin Name: Admin EgoSMS
Description: Sends SMS to the admin phone number when an order is placed or fails using the EgoSMS API.
Version: 1.0.5
Author: KEVINDJ Creatives
Author URI: https://kevindjcreatives.world/
Plugin URI: https://egosms.co/
License: GPLv2 or later
Text Domain: Admin EgoSMS
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

add_action('woocommerce_order_status_processing', 'admin_egosms_order_success');
add_action('woocommerce_order_status_failed', 'admin_egosms_order_failed');
//add_action('woocommerce_order_status_cancelled', 'admin_egosms_order_cancelled');

function admin_egosms_order_success($order_id) {
    
    $order = wc_get_order($order_id);
    $message = "Hello AKRB Manager, you've received a new order with Order ID: " . $order_id . " & Total: UGX" . $order->get_total();
      
    admin_egosms_send_sms($message);
}

function admin_egosms_order_failed($order_id) {
    
    $order = wc_get_order($order_id);
    $message = "Hello AKRB Manager. An order with Order ID: " . $order_id . " has failed.";
    
    admin_egosms_send_sms($message);
}


/*function admin_egosms_order_cancelled($order_id) {
    $order = wc_get_order($order_id);
    $message = "Hello AKRB Manager, an order has been cancelled. Order ID: " . $order_id;

    aadmin_egosms_send_sms($message);
}
*/

function admin_egosms_send_sms($message) {
    
    $admin_phone = get_option('admin_egosms_phone');
    $username = get_option('admin_egosms_username');
    $password = get_option('admin_egosms_password');
    $sender_id = get_option('admin_egosms_sender_id');
    
    if (!$admin_phone || !$username || !$password || !$sender_id) {
        error_log('Admin EgoSMS: Missing API credentials or phone number.');
        return;
    }
    
    
    $url = "www.egosms.co/api/v1/plain/?";
    
    
    $parameters = "number=" . urlencode($admin_phone);
    $parameters .= "&message=" . urlencode($message);
    $parameters .= "&username=" . urlencode($username);
    $parameters .= "&password=" . urlencode($password);
    $parameters .= "&sender=" . urlencode($sender_id);
    
    
    $live_url = "https://" . $url . $parameters;
    
    
    $response = file_get_contents($live_url);
    
    if ($response === false) {
        error_log('Admin EgoSMS: Failed to send SMS.');
    } else {
        error_log('Admin EgoSMS: SMS sent successfully - ' . $response);
    }
}


add_action('admin_menu', 'admin_egosms_settings_menu');

function admin_egosms_settings_menu() {
    add_menu_page(
        'Admin EgoSMS Settings',
        'Admin EgoSMS',
        'manage_options',
        'admin-egosms-settings',
        'admin_egosms_settings_page'
    );
}

function admin_egosms_settings_page() {
    ?>
    <div class="wrap">
        <h1>Admin EgoSMS Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('admin_egosms_settings_group');
            do_settings_sections('admin_egosms_settings_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Admin Phone Number</th>
                    <td><input type="text" name="admin_egosms_phone" value="<?php echo esc_attr(get_option('admin_egosms_phone')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">EgoSMS Username</th>
                    <td><input type="text" name="admin_egosms_username" value="<?php echo esc_attr(get_option('admin_egosms_username')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">EgoSMS Password</th>
                    <td><input type="password" name="admin_egosms_password" value="<?php echo esc_attr(get_option('admin_egosms_password')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">EgoSMS Sender ID</th>
                    <td><input type="text" name="admin_egosms_sender_id" value="<?php echo esc_attr(get_option('admin_egosms_sender_id')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}


add_action('admin_init', 'admin_egosms_register_settings');

function admin_egosms_register_settings() {
    register_setting('admin_egosms_settings_group', 'admin_egosms_phone');
    register_setting('admin_egosms_settings_group', 'admin_egosms_username');
    register_setting('admin_egosms_settings_group', 'admin_egosms_password');
    register_setting('admin_egosms_settings_group', 'admin_egosms_sender_id');
}
